package com.example.intelligent;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;

public class SecondRoom extends Activity{
private Button BtnWen;
private Button BtnWenAdd;
private Button BtnWenSub;
private Button BtnMoCod;
private Button BtnMoWam;
private Button BtnMoWet;
private Button BtnShYao;
private Button BtnXiaYao;
private Button BtnFengSu;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO �Զ����ɵķ������
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.other);
			
	}
	

}
