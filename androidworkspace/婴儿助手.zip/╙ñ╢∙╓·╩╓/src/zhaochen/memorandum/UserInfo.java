package zhaochen.memorandum;

public class UserInfo {
	private String datetime;
	private String content;
	private String alerttime;
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String date) {
		this.datetime = date;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAlerttime() {
		return alerttime;
	}
	public void setAlerttime(String alerttime) {
		this.alerttime = alerttime;
	}

}
